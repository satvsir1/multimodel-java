package com.td.insights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParquetProcessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(ParquetProcessorApplication.class, args);
    }

}
