package com.td.insights.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Component
@Slf4j
public class FileProcessingUtils {
    public File downloadFile(String fileUrl) throws IOException {
        URL url = new URL(fileUrl);
        File tempFile = File.createTempFile("download", ".zip");

        try (InputStream in = url.openStream();
             FileOutputStream out = new FileOutputStream(tempFile)) {
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        return tempFile;
    }

    public File extractZip(File zipFile) throws IOException {
        File extractDir = Files.createTempDirectory("extract").toFile();

        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];

            while ((entry = zis.getNextEntry()) != null) {
                File entryFile = new File(extractDir, entry.getName());

                if (entry.isDirectory()) {
                    entryFile.mkdirs();
                    continue;
                }

                File parent = entryFile.getParentFile();
                if (!parent.exists()) {
                    parent.mkdirs();
                }

                try (FileOutputStream fos = new FileOutputStream(entryFile)) {
                    int len;
                    while ((len = zis.read(buffer)) > 0) {
                        fos.write(buffer, 0, len);
                    }
                }
            }
        }

        return extractDir;
    }

    public List<File> findParquetFiles(File directory) {
        List<File> parquetFiles = new ArrayList<>();
        if (!directory.exists()) return parquetFiles;

        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    parquetFiles.addAll(findParquetFiles(file));
                } else if (file.getName().endsWith(".parquet")) {
                    parquetFiles.add(file);
                }
            }
        }

        return parquetFiles;
    }

    public void cleanup(File... files) {
        for (File file : files) {
            try {
                if (file.isDirectory()) {
                    FileUtils.deleteDirectory(file);  // Using Apache Commons FileUtils
                } else {
                    file.delete();
                }
            } catch (IOException e) {
                log.error("Error cleaning up file: " + file.getPath(), e);
            }
        }
    }
}
