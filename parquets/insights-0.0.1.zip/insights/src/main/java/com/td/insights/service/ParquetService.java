package com.td.insights.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.td.insights.model.ProcessingResponse;
import com.td.insights.util.FileProcessingUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.hadoop.ParquetReader;
import org.apache.parquet.avro.AvroParquetReader;
import org.apache.avro.generic.GenericRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class ParquetService {
    @Autowired
    private FileProcessingUtils fileProcessingUtils;  // Updated field name
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, ProcessingResponse> jobStatus = new ConcurrentHashMap<>();

    @Async
    public String processParquetFromUrl(String fileUrl) throws IOException {
        String jobId = UUID.randomUUID().toString();
        jobStatus.put(jobId, new ProcessingResponse(jobId, "Started"));

        try {
            // Download file
            updateStatus(jobId, "Downloading", 0.2);
            File zipFile = fileProcessingUtils.downloadFile(fileUrl);

            // Extract zip
            updateStatus(jobId, "Extracting", 0.4);
            File extractedDir = fileProcessingUtils.extractZip(zipFile);

            // Process parquet files
            updateStatus(jobId, "Processing Parquet", 0.6);
            List<File> parquetFiles = fileProcessingUtils.findParquetFiles(extractedDir);

            for (File parquetFile : parquetFiles) {
                processParquetFile(parquetFile, jobId);
            }

            // Cleanup
            updateStatus(jobId, "Cleaning up", 0.8);
            fileProcessingUtils.cleanup(zipFile, extractedDir);

            updateStatus(jobId, "Completed", 1.0);
            return jobId;

        } catch (Exception e) {
            log.error("Error processing file: ", e);
            updateStatus(jobId, "Failed: " + e.getMessage(), -1.0);
            throw e;
        }
    }

    private void processParquetFile(File parquetFile, String jobId) throws IOException {
        Configuration conf = new Configuration();
        Path path = new Path(parquetFile.getAbsolutePath());

        try (ParquetReader<GenericRecord> reader = AvroParquetReader
                .<GenericRecord>builder(path)
                .withConf(conf)
                .build()) {

            List<Map<String, Object>> records = new ArrayList<>();
            GenericRecord record;

            while ((record = reader.read()) != null) {
                Map<String, Object> recordMap = convertToMap(record);
                records.add(recordMap);
            }

            // Write to JSON
            String jsonFileName = parquetFile.getName().replace(".parquet", ".json");
            objectMapper.writeValue(new File(jsonFileName), records);
        }
    }

    private Map<String, Object> convertToMap(GenericRecord record) {
        Map<String, Object> map = new HashMap<>();
        record.getSchema().getFields().forEach(field -> {
            String fieldName = field.name();
            Object value = record.get(fieldName);
            map.put(fieldName, value);
        });
        return map;
    }

    private void updateStatus(String jobId, String message, Double progress) {
        ProcessingResponse response = new ProcessingResponse(jobId, "PROCESSING");
        response.setMessage(message);
        response.setProgress(progress);
        jobStatus.put(jobId, response);
    }

    public ProcessingResponse getStatus(String jobId) {
        return jobStatus.getOrDefault(jobId,
                new ProcessingResponse(jobId, "Job not found"));
    }
}
