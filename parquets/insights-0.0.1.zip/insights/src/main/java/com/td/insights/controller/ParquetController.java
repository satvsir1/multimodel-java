package com.td.insights.controller;

import com.td.insights.model.ProcessingResponse;
import com.td.insights.service.ParquetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;

@RestController
@RequestMapping("/api/parquet")
public class ParquetController {
    @Autowired
    private ParquetService parquetService;

    @PostMapping("/process")
    public ResponseEntity<ProcessingResponse> processParquetFile(
            @RequestParam("url") String fileUrl) {
        try {
            String jobId = parquetService.processParquetFromUrl(fileUrl);
            return ResponseEntity.ok(new ProcessingResponse(jobId, "Processing Started"));
        } catch (Exception e) {
            return ResponseEntity.status(500)
                    .body(new ProcessingResponse(null, "Error: " + e.getMessage()));
        }
    }

    @GetMapping("/status/{jobId}")
    public ResponseEntity<ProcessingResponse> getStatus(@PathVariable String jobId) {
        return ResponseEntity.ok(parquetService.getStatus(jobId));
    }
}
