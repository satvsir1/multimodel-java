package com.td.insights.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessingResponse {
    private String jobId;
    private String status;
    private String message;
    private Double progress;

    public ProcessingResponse(String jobId, String message) {
        this.jobId = jobId;
        this.message = message;
        this.status = "PROCESSING";
        this.progress = 0.0;
    }
}
